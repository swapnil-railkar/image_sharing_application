package com.example.variablesharing;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toolbar;

public class Sendactivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sendactivity);
        Toolbar toolbar=(Toolbar)findViewById(R.id.toolbarsend);
        setActionBar(toolbar);
    }
}