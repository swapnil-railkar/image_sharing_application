package com.example.variablesharing;


import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Toolbar;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       Toolbar toolbar=(Toolbar)findViewById(R.id.toolbar);
       setActionBar(toolbar);
    }

    public void onclickrecieve(View view) {
        Intent intent=new Intent(this,Recieveactivity.class);
    }

    public void onclicksend(View view) {
        Intent intent=new Intent(this,Sendactivity.class);
    }


}