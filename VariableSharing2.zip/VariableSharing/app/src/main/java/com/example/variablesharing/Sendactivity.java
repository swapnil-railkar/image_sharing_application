package com.example.variablesharing;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class Sendactivity extends AppCompatActivity {
    TextView pathtext;
    ImageView img;

    public int image_pick_code=1000;
    public int permission_code=1001;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sendactivity);
        Toolbar toolbar=(Toolbar)findViewById(R.id.toolbarsend);
        setSupportActionBar(toolbar);
        ActionBar actionBar=getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
    }
    public void onclickgetfile(View view)
    {
         pathtext=(TextView)findViewById(R.id.textView);
         img=(ImageView)findViewById(R.id.imageView);

        if(checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)==getPackageManager().PERMISSION_DENIED)
        {
            //permission not granted,request it
            String[] permissions={Manifest.permission.READ_EXTERNAL_STORAGE};
            //popup for runtime permissions
            requestPermissions(permissions,permission_code);
        }else
        {
            //permission already granted
            pickimagefromgallery();
        }

    }


    public void pickimagefromgallery()
    {
        Intent intent=new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent,image_pick_code);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch(requestCode)
        {
            case 1001:{
                if(grantResults.length>0 && grantResults[0]==getPackageManager().PERMISSION_GRANTED)
                    pickimagefromgallery();
                else Toast.makeText(this,"permission denied",Toast.LENGTH_SHORT).show();
                }
                break;

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode==RESULT_OK && requestCode==image_pick_code)
        {
            img.setImageURI(data.getData());
            String path=data.getData().getPath();
            pathtext.setText("Path: "+path);
        }

    }

    public void onclickstartsharing(View view) {
        Intent intent =new Intent(this,SharingScreen.class);
        startActivity(intent);
    }
}

